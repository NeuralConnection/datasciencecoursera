#Assignment Part 1 for Week2 - R Coursera, JHU
print(R.version.string)
function pollutantmean(C:\r\repos\datasciencecoursera\specdata, sulface, id=001:322
                       